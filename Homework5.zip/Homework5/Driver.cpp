/**
 * Name: David Dataram
 * Class: CS211 Lab - MW 7:30pm-8:20pm
 * HW #5
 */
#include <iostream>
#include "Date.h"
#include "Student.h"
#include "Roster.h"
int main(){
    Roster r;
    std::cin >> r;
    std::cout << r;
    return 0;
}