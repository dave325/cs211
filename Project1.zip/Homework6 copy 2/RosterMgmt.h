#ifndef ROSTERMGMT_H
#define ROSTERMGMT_H
#include "Roster.h"

class RosterMgmt{
    private:
        int size;
        int curr;
        Roster** rosters; 
        void grow();
        void openRoster();
        void closeRoster();
        Roster* findRoster(std::string courseNum);
        std::string parseStr(std::string &s, std::string d, int &pos);
    public:
        RosterMgmt();
        ~RosterMgmt();
        RosterMgmt(RosterMgmt& r);
        void addRoster(Roster* r);
        void dropRoster();
        void displayRoster(std::string& ans);
        void displayAllRoster();
        void insertStudent(std::string courseNum);
        void removeStudent(std::string courseNum);
        void updateStudent(std::string courseNum);
        Roster* sortStudents(std::string courseNum);
        RosterMgmt& operator=(RosterMgmt& r);

};

#endif
