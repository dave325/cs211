#include "Roster.h"
#include "RosterMgmt.h"
#include <string>
#include <sstream>
#include <fstream>

RosterMgmt::RosterMgmt(){
    size = 1;
    curr = 0;
    rosters = new Roster*[size];
    openRoster();
}
RosterMgmt::~RosterMgmt(){
    closeRoster();
    for(int i = 0; i < curr; i++){
        delete rosters[i];
    }
    delete[] rosters;
}
void RosterMgmt::openRoster(){
    fstream roster("rosters.txt");
    if(!roster.is_open()){
        std::cerr << "File does not exist" << std::endl;
        return;
    }
    
    int i = 0;
    char c[256];
    std::string tempStr;
    int tempNum;
    double tempDouble;
    int tempDate[3];
    while(roster){
        if(roster.peek() == EOF){
            return;
        }
        if(curr == size){
            grow();
        }
        Roster* r = new Roster();
        addRoster(r);
        roster.getline(c, 50, '|');
        tempStr = c;
        tempStr.erase(std::remove(tempStr.begin(),tempStr.end(),' '),tempStr.end());
        rosters[i]->setCourseName(tempStr);
        roster.getline(c, 50, '|');
        tempStr = c;
        tempStr.erase(std::remove(tempStr.begin(),tempStr.end(),' '),tempStr.end());
        rosters[i]->setCourseCode(tempStr);
        roster.getline(c, 50, '|');
        tempStr =c;
        tempStr.erase(std::remove(tempStr.begin(),tempStr.end(),' '),tempStr.end());
        tempNum = stoi(tempStr);
        rosters[i]->setNumCredits(tempNum);
        roster.getline(c, 50);
        tempStr = c;
        tempStr.erase(std::remove(tempStr.begin(),tempStr.end(),' '),tempStr.end());
        rosters[i]->setInstructorName(tempStr);
        while(roster.getline(c,256, '\n')){
            std::cout << c << std::endl;
            tempStr = c;
            std::string token;
            int pos = 0;
            std::string delimiter = "|";
            std::cout << tempStr;
            if(tempStr == "end_roster|"){
                roster.ignore();
                break;
            }
            Student* s = new Student(rosters[i]->getCurr());
            token = parseStr(tempStr,delimiter, pos);
            s->setFirstName(token);
            token = parseStr(tempStr,delimiter, pos);
            s->setLastName(token);
            parseStr(tempStr,delimiter, pos);
            parseStr(tempStr,delimiter, pos);
            token = parseStr(tempStr,delimiter, pos);
            tempNum = stoi(token);
            s->setCredits(tempNum);
            token = parseStr(tempStr,delimiter, pos);
            tempDouble = stod(token);
            s->setGpa(tempDouble);
            token = parseStr(tempStr,delimiter, pos);
            std::replace(token.begin(), token.end(), '/', ' '); 
            std::stringstream ss(token);
            ss >> tempDate[0];
            ss >> tempDate[1];
            ss >> tempDate[2];
            Date d(tempDate[0],tempDate[1],tempDate[2]);
            s->setDateOfBirth(d);
            token = parseStr(tempStr,delimiter, pos);
            std::replace(token.begin(), token.end(), '/', ' '); 
            ss.clear();
            ss.str(token);
            ss >> tempDate[0];
            ss >> tempDate[1];
            ss >> tempDate[2];
            Date d1(tempDate[0],tempDate[1],tempDate[2]);
            s->setMatriculationDate(d1);
            rosters[i]->addStudent(s);
        }  
        i++;
    }
    std::cout << size << std::endl;
    roster.close();
}

void RosterMgmt::closeRoster(){
    ofstream roster("rosters.txt");
    if(!roster.is_open()){
        std::cerr << "File does not exist" << std::endl;
        return;
    }
    int i = 0;
    while(i < curr){
        roster << rosters[i]->getCourseName() << "|";
        roster << rosters[i]->getCourseCode() << "|";
        roster << rosters[i]->getNumCredits() << "|";
        roster << rosters[i]->getInstructorName() <<std::endl;
        int j = 0;
        while(j < rosters[i]->getCurr()){
            Student* s = (*rosters[i])[j];
            roster << s->getFirstName() << "|";
            roster << s->getLastName() << "|";
            roster << s->getId()<< "|";
            roster << s->getStanding()<< "|";
            roster << s->getCredits()<< "|" ;
            roster << s->getGpa()<< "|" ;
            roster << s->getDateOfBirth().getMonthNum() << "/" << s->getDateOfBirth().getDay() << "/" << s->getDateOfBirth().getYear() << "|";
            roster << s->getMatriculationDate().getMonthNum() << "/" << s->getMatriculationDate().getDay() << "/" << s->getMatriculationDate().getYear() << std::endl;
            j++;
        }
        i++;
        roster << "end_roster|"  << std::endl;
    }
    roster.close();

}
void RosterMgmt::addRoster(Roster* r){
    curr++;
    if(size == curr){
        grow();
    }
    rosters[curr-1] = r;
}

void RosterMgmt::dropRoster(){
    if (size == 0)
    {
        return;
    }
    std::string s;
    std::cout << "Please include course Number "<<std::endl;
    std::cin >> s;
    curr--;
    int i = 0; 
    int point = size;
    Roster** temp = new Roster*[size];
    while(i < curr){
        if(rosters[i]->getCourseCode() == s){
            point = i;
            temp[i] = rosters[i+1];
            i++;
            continue;
        }
        if(point < i){
            temp[i] = rosters[i+1];
            i++;
            continue;
        }
        temp[i] = rosters[i];
        i++;
    }
    delete[] rosters;
    rosters = temp;
}

void RosterMgmt::displayRoster(std::string& ans){
    std::cout << "Please enter the course you wish to view" <<std::endl;
    std::cin >> ans;
    for(int i = 0; i < curr; i++){
        if(rosters[i]->getCourseCode() == ans){
            std::cout << *rosters[i];
            return;
        }
    }
    std::cerr << "Course does not exist" << std::endl;
}
void RosterMgmt::displayAllRoster(){
    std::cout << "Current roster num" << curr;
    for(int i = 0; i < curr; i++){
         std::cout << *rosters[i];
    }
}

void RosterMgmt::insertStudent(std::string courseNum){
    Student* s = new Student();
    std::cin >> *s;
    Roster* temp = findRoster(courseNum);
    temp->addStudent(s);
    return;
}

void RosterMgmt::removeStudent(std::string courseNum){
    Student* s = new Student();
    Roster* temp;
    if(findRoster(courseNum)){
        temp = findRoster(courseNum);
    }else{
        return;
    }
    int id;
    std::cout << "Enter Student id number" << std::endl;
    std::cin >> id;
    
    for(int i = 0; i < temp->getCurr(); i++){
        if(id == (*temp)[i]->getId()){
            s = (*temp)[i];
            temp->deleteStudent(s);
            return;
        }
    }
}
void RosterMgmt::updateStudent(std::string courseNum){
    Roster* temp;
    if(findRoster(courseNum)){
        temp = findRoster(courseNum);
    }else{
        return;
    }
    int id;
    std::cout << "Enter Student id number" << std::endl;
    std::cin >> id;
    
    for(int i = 0; i < temp->getCurr(); i++){
        if(id == (*temp)[i]->getId()){
            std::cin >> *(*temp)[i];
            return;
        }
    }
    
}
Roster* RosterMgmt::sortStudents(std::string courseNum){
    Roster* sort = findRoster(courseNum);
    sort->sortStudents();
    return sort;
}
std::string RosterMgmt::parseStr(std::string &s, std::string d, int &pos){
    pos = s.find(d);
    std::string s1 = s.substr(0, pos);
    s.erase(0, pos + d.length());
    return s1;
}

void RosterMgmt::grow(){
    size = size + 10;
    Roster** temp = new Roster*[size];
    for(int i = 0; i < size - 10; i++){
        temp[i] = rosters[i];
    }
    delete[] rosters;
    rosters = temp;
}

Roster* RosterMgmt::findRoster(std::string courseNum){
    for(int i = 0; i < curr; i++){
        if(rosters[i]->getCourseCode() == courseNum){
            return rosters[i];
        }
    }
    std::cout << "No roster found" << std::endl;
    return NULL;
}

RosterMgmt& RosterMgmt::operator=(RosterMgmt& r){
    if(this == &r){
        return *this;
    }
    size = r.size;
    curr = r.curr;
    for(int i = 0; i < curr; i++){
        rosters[i] = r.rosters[i];
    }
    return *this;
}