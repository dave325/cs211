#include <string>
#include <iostream>
#include "Roster.h"
#include "Student.h"

Roster::Roster(){
    course_name = "";
    course_code = "";
    num_credits = 0;
    instructor_name = "";
    size = 1;
    curr = 0;
    students = new Student*[size];
}

 Roster::Roster(const Roster& other){
    course_name = other.course_name;
    course_code = other.course_code;
    num_credits = other.num_credits;
    instructor_name = other.instructor_name;
    size = other.size;
    for(int i = 0; i < size; i++){
        students[i] = new Student(*other.students[i]);
    }
 }

int Roster::getCurr(){
    return curr;
}

void Roster::grow(){
    size = size + 10;
    Student** temp = new Student*[size];
    for(int i = 0; i < size - 10; i++){
        temp[i] = students[i];
    }
    delete[] students;
    students = temp;
}


Roster::~Roster(){
    for(int i = 0; i < size; i++){
        delete students[i];
    }
    delete[] students;
}

// Retrieve Course Number
std::string Roster::getCourseName() const{
    return course_name;
}
// Sets course number
void Roster::setCourseName(std::string courseName){
    course_name = courseName;
}
// Retrieves Course Code
std::string Roster::getCourseCode() const{
    return course_code;
}

// Sets Course code
void Roster::setCourseCode(std::string courseCode){
    course_code = courseCode;
}

// Retrieves num_credits
int Roster::getNumCredits() const{
    return num_credits;
}

// Sets num_credits
void Roster::setNumCredits(int num){
    num_credits = num;
}

// Retrieves instructor name
std::string Roster::getInstructorName() const{
    return instructor_name;
}

// Sets instructor name
void Roster::setInstructorName(std::string name){
    instructor_name = name;
}

// Adds Student to array
void Roster::addStudent(Student* student){
    curr++;
    if(size == curr){
        grow();
    }
   students[curr - 1] = student;
}

// Deletes student
void Roster::deleteStudent(Student* student){
       if (size == 0)
    {
        return;
    }
    curr--;
    int i = 0; 
    int point = size;
    Student** temp = new Student*[size];
    while(i < curr){
        if(students[i]->getId() == student->getId()){
            point = i;
            temp[i] = students[i+1];
            i++;
            continue;
        }
        if(point < i){
            temp[i] = students[i+1];
            i++;
            continue;
        }
        temp[i] = students[i];
        i++;
    }
    delete[] students;
    students = temp;
}


// Searches for student
Student* Roster::searchStudent(Student* student)const{
    for(int i= 0; i< size; i++){
        // If student is found, then return student
        if(students[i] == student){
            return students[i];
        }
    }
    // If no student is found the return
    std::cout << "Index does not exist" << std::endl;
    exit(0);
}

void Roster::sortStudents(){
   int i, j;
   Student* key;
   for (i = 1; i < curr; i++)
   {
       key = students[i];
       j = i-1;
       /* Move elements of arr[0..i-1], that are
          greater than key, to one position ahead
          of their current position */ 
          std::cout << j << std::endl;
       while (j >= 0 && *students[j] > *key)
       {
           students[j+1] = students[j];
           j = j-1;
       }
       students[j+1] = key;
   }
}

Student* Roster::operator[](const int idx){
    if(idx > curr || idx < 0){
        std::cout << "Index does not exist" << std::endl;
        exit(0);
    }
    if(curr == 0){
        std::cout << "No Students" <<std::endl;
        return NULL;
    }
    return students[idx];
}

Roster& Roster::operator=(const Roster& other){
    if (this == &other)
      return *this;
    course_name = other.course_name;
    course_code = other.course_code;
    num_credits = other.num_credits;
    instructor_name = other.instructor_name;
    size = other.size;
    for(int i = 0; i < size; i++){
        students[i] = other.students[i];
    }

    return *this;
}

// Prints out all students
const std::ostream& operator<<(std::ostream& os, Roster& r){
    os << "Course Name: " << r.course_name << std::endl;
    os << "Course Code: " << r.course_code << std::endl;
    os << "Number of Credits: " << r.num_credits << std::endl;
    os << "Instructor Name: " << r.instructor_name << std::endl;
    if(r.curr == 0){
        os << "No students are registered" << std::endl;
    }else{
        for(int i = 0; i < r.curr; i++){
            // Print out student if value is found
        os << "Student " << i << ": " << std::endl << *r.students[i];
        }
    }
    return os;
}

const std::istream& operator>>(std::istream& is, Roster& r){
    std::string courseName, courseCode,insName;
    char ans;
    int credits;
    int i = 0;
    std::cout << "Course Name: " << r.course_name << std::endl;
    std::cin >> courseName; r.setCourseName(courseName);
    std::cout << "Course Code: " << r.course_code << std::endl;
    std::cin >> courseCode; r.setCourseCode(courseCode);
    std::cout << "Number of Credits: " << r.num_credits << std::endl;
    std::cin >> credits; r.setNumCredits(credits);
    std::cout << "Instructor Name: " << r.instructor_name << std::endl;
    std::cin >> insName; r.setInstructorName(insName);
    std::cout << "Please include any students that you may have" <<std::endl;
    while(ans != 'N'){
        std::cout << "Do you want to add students. Y for yes, N for no" << std::endl;
        std::cin >> ans;
        ans = toupper(ans);
        if(ans == 'Y'){
            if(r.curr == r.size){
                r.grow();
            }
            std::cout << r.curr;
            Student* s = new Student(r.curr);
            is >> *s;
            r.addStudent(s);
            i++;
        }
    }
    return is;
}