#include <string>
#include <iostream>
#include "Roster.h"
#include "Student.h"
int Student::idCount = 0;

Roster::Roster(){
    course_name = "";
    course_code = "";
    num_credits = 0;
    instructor_name = "";
    size = 1;
    curr = 0;
    students = new Student*[size];
}

 Roster::Roster(const Roster& other){
    course_name = other.course_name;
    course_code = other.course_code;
    num_credits = other.num_credits;
    instructor_name = other.instructor_name;
    size = other.size;
    for(int i = 0; i < size; i++){
        students[i] = new Student(*other.students[i]);
    }
 }

int Roster::getCurr(){
    return curr;
}

void Roster::grow(){
    size = size + 10;
    Student** temp = new Student*[size];
    for(int i = 0; i < size - 10; i++){
        temp[i] = students[i];
    }
    delete[] students;
    students = temp;
}


Roster::~Roster(){
    for(int i = 0; i < size; i++){
        delete students[i];
    }
    delete[] students;
}

// Retrieve Course Number
std::string Roster::getCourseName() const{
    return course_name;
}
// Sets course number
void Roster::setCourseName(std::string courseName){
    course_name = courseName;
}
// Retrieves Course Code
std::string Roster::getCourseCode() const{
    return course_code;
}

// Sets Course code
void Roster::setCourseCode(std::string courseCode){
    course_code = courseCode;
}

// Retrieves num_credits
int Roster::getNumCredits() const{
    return num_credits;
}

// Sets num_credits
void Roster::setNumCredits(int num){
    num_credits = num;
}

// Retrieves instructor name
std::string Roster::getInstructorName() const{
    return instructor_name;
}

// Sets instructor name
void Roster::setInstructorName(std::string name){
    instructor_name = name;
}

// Adds Student to array
void Roster::addStudent(Student* student){
    curr++;
    if(size == curr){
        grow();
    }
    students[curr - 1] = student;
}

// Deletes student
void Roster::deleteStudent(Student* student){
       if (size == 0)
    {
        return;
    }
    curr--;
    int i = 0; 
    int point = size;
    Student** temp = new Student*[size];
    while(i < curr){
        if(students[i]->getId() == student->getId()){
            point = i;
            temp[i] = students[i+1];
            i++;
            continue;
        }
        if(point < i){
            temp[i] = students[i+1];
            i++;
            continue;
        }
        temp[i] = students[i];
        i++;
    }
    delete[] students;
    students = temp;
}


// Searches for student
Student* Roster::searchStudent(Student* student)const{
    for(int i= 0; i< size; i++){
        // If student is found, then return student
        if(students[i] == student){
            return students[i];
        }
    }
    // If no student is found the return
    std::cout << "Index does not exist" << std::endl;
    exit(0);
}

void Roster::sortStudents(){
   int i, j;
   Student* key;
   for (i = 1; i < size; i++)
   {
       key = students[i];
       j = i-1;
       /* Move elements of arr[0..i-1], that are
          greater than key, to one position ahead
          of their current position */ 
       while (j >= 0 && students[j] > key)
       {
           students[j+1] = students[j];
           j = j-1;
       }
       students[j+1] = key;
   }
}

Student* Roster::operator[](int idx) const{
    if(idx > curr || idx < 0){
        std::cout << "Index does not exist" << std::endl;
        exit(0);
    }
    return students[idx];
}

Roster& Roster::operator=(const Roster& other){
    if (this == &other)
      return *this;
    course_name = other.course_name;
    course_code = other.course_code;
    num_credits = other.num_credits;
    instructor_name = other.instructor_name;
    size = other.size;
    for(int i = 0; i < size; i++){
        students[i] = other.students[i];
    }

    return *this;
}

// Prints out all students
const std::ostream& operator<<(std::ostream& os, Roster& r){
    for(int i = 0; i < r.curr; i++){
        // Print out student if value is found
       os << "Student " << i << ": " << std::endl << *r.students[i];
    }
    return os;
}

const std::istream& operator>>(std::istream& is, Roster& r){
    std::string ans;
    int i = 0;
    do{
        if(r.curr == r.size){
            r.grow();
        }
        std::cout << r.curr;
        Student* s = new Student();
        is >> *s;
        r.addStudent(s);
        std::cout << "Do you want to add more students. Y for yes, N for no" << std::endl;
        std::cin >> ans;
        // Retrive the lowercase value
        transform(ans.begin(), ans.end(), ans.begin(), ::tolower);
        i++;
    }while(ans == "y");
    return is;
}