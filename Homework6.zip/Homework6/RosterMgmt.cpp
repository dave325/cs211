#include "Roster.h"
#include "RosterMgmt.h"
#include <string>
#include <sstream>
#include <fstream>
/**
 * Basic CRUD Class to alter roster and students within those roster
 */

/**
 * Default Constructor 
 */ 
RosterMgmt::RosterMgmt(){
    size = 1;
    curr = 0;
    rosters = new Roster*[size];
    for(int i =0; i < size; i++)
    {
        rosters[i] = NULL; 
    }
    openRoster();
}

// Copy constructor
RosterMgmt::RosterMgmt(const RosterMgmt& r){
    size = r.size;
    curr = r.curr;
    for(int i = 0; i < curr; i++){
        rosters[i] = r.rosters[i];
    }
}
/**
 * Destructor for Roster Management
 */ 
RosterMgmt::~RosterMgmt(){
    closeRoster();
    for(int i = 0; i < curr; i++){
        delete rosters[i];
    }
    delete[] rosters;
}

/**
 * openRoster - Call to txt file with the information for classes 
 * and returns into the dynamic array 
 * private function
 */ 
void RosterMgmt::openRoster(){
    // opens roster.txt 
    fstream roster("rosters.txt");
    // Ends the program 
    if(!roster.is_open()){
        std::cerr << "File does not exist" << std::endl;
        return;
    }
    // Iterator for the roster array
    int i = 0;
    // char array for each line 
    char c[500];
    // temporary string to hold parts of the aray
    std::string tempStr;
    // temp num to hold part of array
    int tempNum;
    // temp double to hold of array
    double tempDouble;
    // temp int to hold array
    int tempDate[3];
    // Loop through file 
    while(roster){
        // checks if EOF and returns 
        if(roster.peek() == EOF){
            return;
        }
        // If ax size is reached, then grow array
        if(curr == size){
            grow();
        }
        // Instantiate new Roster pointer 
        Roster* r = new Roster();
        // Add roster 
        addRoster(r);
        // gets the line up to the delimiter 
        roster.getline(c, 50, '|');
        // store char array as a  temp string 
        tempStr = c;
        // Remove any spaces 
        tempStr.erase(std::remove(tempStr.begin(),tempStr.end(),' '),tempStr.end());
        // Set values 
        rosters[i]->setCourseName(tempStr);
        roster.getline(c, 50, '|');
        tempStr = c;
        tempStr.erase(std::remove(tempStr.begin(),tempStr.end(),' '),tempStr.end());
        rosters[i]->setCourseCode(tempStr);
        roster.getline(c, 50, '|');
        tempStr =c;
        tempStr.erase(std::remove(tempStr.begin(),tempStr.end(),' '),tempStr.end());
        tempNum = stoi(tempStr);
        rosters[i]->setNumCredits(tempNum);
        roster.getline(c, 50, '\n');
        tempStr = c;
        tempStr.erase(std::remove(tempStr.begin(),tempStr.end(),' '),tempStr.end());
        rosters[i]->setInstructorName(tempStr);
        // Loop through lines of code for students 
        while(roster.getline(c,256, '\n')){
            tempStr = c;
            // temp string to store each line 
            std::string token;
            // Sets specific position of each line to remove 
            int pos = 0;
            // sets delimiter for parsing 
            std::string delimiter = "|";
            // if end of roster is reached, end code 
            if(tempStr == "end_roster|"){
                break;
            }
            // Set student pointer 
            Student* s = new Student(rosters[i]->getCurr());
            // Creates a token based on delimiter 
            token = parseStr(tempStr,delimiter, pos);
            s->setFirstName(token);
            token = parseStr(tempStr,delimiter, pos);
            s->setLastName(token);
            parseStr(tempStr,delimiter, pos);
            parseStr(tempStr,delimiter, pos);
            token = parseStr(tempStr,delimiter, pos);
            tempNum = stoi(token);
            s->setCredits(tempNum);
            token = parseStr(tempStr,delimiter, pos);
            tempDouble = stod(token);
            s->setGpa(tempDouble);
            token = parseStr(tempStr,delimiter, pos);
            std::replace(token.begin(), token.end(), '/', ' '); 
            std::stringstream ss(token);
            ss >> tempDate[0];
            ss >> tempDate[1];
            ss >> tempDate[2];
            Date d(tempDate[0],tempDate[1],tempDate[2]);
            s->setDateOfBirth(d);
            token = parseStr(tempStr,delimiter, pos);
            std::replace(token.begin(), token.end(), '/', ' '); 
            ss.clear();
            ss.str(token);
            ss >> tempDate[0];
            ss >> tempDate[1];
            ss >> tempDate[2];
            Date d1(tempDate[0],tempDate[1],tempDate[2]);
            s->setMatriculationDate(d1);
            // Adds date to roster 
            rosters[i]->addStudent(s);
        }  
        // Iterate to next roster 
        i++;
    }
    // close the roster fstream 
    roster.close();
}

/**
 * closeRoster - outputs roster array into txt file 
 * private function 
 */ 
void RosterMgmt::closeRoster(){
    ofstream roster("rosters.txt");
    if(!roster.is_open()){
        std::cerr << "File does not exist" << std::endl;
        return;
    }
    int i = 0;
    // loop through array and write to file
    while(i < curr){
        roster << rosters[i]->getCourseName() << "|";
        roster << rosters[i]->getCourseCode() << "|";
        roster << rosters[i]->getNumCredits() << "|";
        roster << rosters[i]->getInstructorName() <<std::endl;
        int j = 0;
        // loop through students 
        while(j < rosters[i]->getCurr()){
            Student* s = (*rosters[i])[j];
            roster << s->getFirstName() << "|";
            roster << s->getLastName() << "|";
            roster << s->getId()<< "|";
            roster << s->getStanding()<< "|";
            roster << s->getCredits()<< "|" ;
            roster << s->getGpa()<< "|" ;
            roster << s->getDateOfBirth().getMonthNum() << "/" << s->getDateOfBirth().getDay() << "/" << s->getDateOfBirth().getYear() << "|";
            roster << s->getMatriculationDate().getMonthNum() << "/" << s->getMatriculationDate().getDay() << "/" << s->getMatriculationDate().getYear() << std::endl;
            j++;
        }
        i++;
        roster << "end_roster|"  << std::endl;
    }
    roster.close();

}
void RosterMgmt::addRoster(Roster* r){
    curr++;
    if(size == curr){
        grow();
    }
    if(r == NULL){
        Roster* r1 = new Roster();
        std::cin >> *r1;
        rosters[curr-1] = r1;
        return;
    }
    rosters[curr-1] = r;
}

void RosterMgmt::dropRoster(){
    if (size == 0)
    {
        return;
    }
    std::string s;
    std::cout << "Please include course Number "<<std::endl;
    std::cin >> s;
    // Reduces current size 
    curr--;
    int i = 0; 
    // sets the check point for the iterator, i
    int point = size;
    // Create a temp with the size 
    Roster** temp = new Roster*[size];

    while(i < curr){
        if(rosters[i]->getCourseCode() == s){
            point = i;
            temp[i] = rosters[i+1];
            i++;
            continue;
        }
        if(point < i){
            temp[i] = rosters[i+1];
            i++;
            continue;
        }
        temp[i] = rosters[i];
        i++;
    }
    delete[] rosters;
    rosters = temp;
}

void RosterMgmt::displayRoster(std::string& ans){
    std::cout << "Please enter the course you wish to view" <<std::endl;
    std::cin >> ans;
    for(int i = 0; i < curr; i++){
        if(rosters[i]->getCourseCode() == ans){
            std::cout << *rosters[i];
            return;
        }
    }
    std::cerr << "Course does not exist" << std::endl;
}
void RosterMgmt::displayAllRoster(){
    std::cout << "Current roster num" << curr;
    for(int i = 0; i < curr; i++){
         std::cout << *rosters[i];
    }
}

void RosterMgmt::insertStudent(std::string courseNum){
    Roster* temp = findRoster(courseNum);
    Student* s = new Student(temp->getCurr());
    std::cin >> *s;
    temp->addStudent(s);
    return;
}

void RosterMgmt::removeStudent(std::string courseNum){
    Student* s = new Student();
    Roster* temp;
    if(findRoster(courseNum)){
        temp = findRoster(courseNum);
    }else{
        return;
    }
    int id;
    std::cout << "Enter Student id number" << std::endl;
    std::cin >> id;
    
    for(int i = 0; i < temp->getCurr(); i++){
        if(id == (*temp)[i]->getId()){
            s = (*temp)[i];
            temp->deleteStudent(s);
            return;
        }
    }
}
void RosterMgmt::updateStudent(std::string courseNum){
    Roster* temp;
    if(findRoster(courseNum)){
        temp = findRoster(courseNum);
    }else{
        return;
    }
    int id;
    std::cout << "Enter Student id number" << std::endl;
    std::cin >> id;
    
    for(int i = 0; i < temp->getCurr(); i++){
        if(id == (*temp)[i]->getId()){
            std::cin >> *(*temp)[i];
            return;
        }
    }
}
Roster* RosterMgmt::sortStudents(std::string courseNum){
    Roster* sort = findRoster(courseNum);
    sort->sortStudents();
    return sort;
}

/**
 * Private function
 * Parses string and returns it be next section 
 */ 
std::string RosterMgmt::parseStr(std::string &s, std::string d, int &pos){
    pos = s.find(d);
    std::string s1 = s.substr(0, pos);
    s.erase(0, pos + d.length());
    return s1;
}

void RosterMgmt::grow(){
    size = size + 10;
    Roster** temp = new Roster*[size];
    for(int i = 0; i < curr; i++){
        temp[i] = rosters[i];
    }
    delete[] rosters;
    rosters = temp;
}

Roster* RosterMgmt::findRoster(std::string courseNum){
    for(int i = 0; i < curr; i++){
        if(rosters[i]->getCourseCode() == courseNum){
            return rosters[i];
        }
    }
    std::cout << "No roster found" << std::endl;
    return NULL;
}

RosterMgmt& RosterMgmt::operator=(RosterMgmt& r){
    if(this == &r){
        return *this;
    }
    size = r.size;
    curr = r.curr;
    for(int i = 0; i < curr; i++){
        rosters[i] = r.rosters[i];
    }
    return *this;
}