/**
 * Name: David Dataram
 * Class: CS211 Lab - MW 7:30pm-8:20pm
 * HW #6
 */
#include <iostream>
#include <fstream>
#include <string>
#include "Date.h"
#include "Student.h"
#include "Roster.h"
int main(){
    
    Roster r;
    std::cin >> r;
    Student* s = new Student();
    Student* s1 = new Student();
    Student* s2 = new Student();
    Student* s3 = new Student();
    Student* s4 = new Student();
    r.addStudent(s4);
    std::cout << r;
    //r.deleteStudent(s3);
    //std::cout << *r.searchStudent(s3);
    // Section below is for the project 
  /*
    char ans;
    int att = 0;
    std::cout << "Roster Management Program" <<std::endl
        << "Please select an option to proceed" << std::endl
        << "Press s for Supervisor Mode" << std::endl
        << "Press u for User Mode" << std::endl
        << "Press e to exit" << std::endl;
    std::cin >> ans;
    while(ans == 's' && ans == 'u' && ans == 'e'){
        if (att == 3){
            std::cout << "Too many tries. Terminating program." <<std::endl;
            exit(0);
        }
        std::cout << "Wrong input please try again!" 
            << "Please select an option to proceed" << std::endl
            << "Press s for Supervisor Mode" << std::endl
            << "Press u for User Mode" << std::endl
            << "Press e to exit" << std::endl;
        std::cin >> ans;
        att++;
    }
    if(ans == 's'){
        std::cout << "Reached";
        fstream file;
        file.open("database.txt");
        if (!file.is_open()) { 
            std::cerr << "File does not exist" << std::endl;
            return 0;
        }
        std::string user, pass,userCheck, passCheck;
        bool found = false;
        std::cout << "Please enter username and password.";
        std::cin >> user >> pass;
        while(file >> userCheck >> passCheck && !found){
            if(user == userCheck && pass == passCheck){
                found = true;
            }
        }
        file.close();
        if(!found){
            std::cout << user << " not found or wrong password!" << std::endl;
            exit(0);
        }
        std::cout << "Found";
        int size = 5;
        Roster* rosters = new Roster[size];
    }
*/

    return 0;
}