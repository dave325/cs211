#include <iostream>
#include <string>
#include <fstream>
#include "Date.h"
#include "Student.h"
#include "Roster.h"
#include "RosterMgmt.h"
/**
 *  Name: David Dataram
 *  Class: CS211 MW 7:30-8:20PM
 */
char menu();
char altRosterSup();
char altRosterReg();
int main(){
    RosterMgmt r;
    char response, altRoster, men;
    std::string user, pass, userTry, passTry, ans, rosterNum;
    int att = 0;
    std::cout << "Welcome to the Roster Management system!" << std::endl
        << "Press s for Supervisor Mode" <<std::endl
        << "Press u for User Mode" << std::endl
        << "Press e to exit" << std::endl;
    std::cin >> response;
    response = toupper(response);
    while(response != 'S' && response != 'U' && response != 'E'){
        std::cout << "Incorrect response please try again!" << std::endl;
        att++;
    }
    if(response == 'S'){
        fstream file("database.txt");
        if(!file.is_open()){
            std::cerr << "No file available" << std::endl;
            return 0;
        }

        std::cout << "Please enter a user name and password" << std::endl;
        std::cin >> userTry >> passTry;
        while(file >> user >> pass){
            if(userTry == user && passTry == pass){
                std::cout << "Successfully logged in. " << std::endl;
                break;
            }else if(file.eof()){
                std::cout << "No user found, please try again" << std::endl;
                return 0;
            }
        }
        while(men != '5'){
            men = menu();
            switch(men){
                case '1':
                    r.addRoster(NULL);
                    std::cout << "Successfully added roster" << std::endl;
                    break;
                case '2':
                    r.dropRoster();
                    std::cout << "Successfully dropped roster" << std::endl;
                    break;
                case'3':
                    r.displayRoster(rosterNum);
                    while(altRoster != '5'){
                        altRoster = altRosterSup();
                        switch(altRoster){
                            case '1':
                                r.insertStudent(rosterNum);
                                std::cout << "Successfully added student" << std::endl;
                                break;
                            case '2':
                                r.removeStudent(rosterNum);
                                std::cout << "Successfully dropped student" << std::endl;
                                break;
                            case '3':
                                r.updateStudent(rosterNum);
                                std::cout << "Successfully updated student" <<std::endl;
                                break;
                            case '4':
                                std::cout << *r.sortStudents(rosterNum);
                                std::cout << "Successfully sorted students" << std::endl;
                                break;
                            case '5':
                                std::cout << "Returning to menu" <<std::endl;
                                break;
                            default:
                                std::cout <<"No option found" << std::endl;
                                break;
                        }
                    }
                    break;
                case '4':
                    r.displayAllRoster();
                    break;
                case '5':
                    std::cout << "Ending program..." <<std::endl;
                    break;
                default:
                    std::cout <<"Number you have added is not valid. Try again." <<std::endl;
                    break;
            }
        }
    }
    if(response == 'U'){
        while(altRoster != '4'){
            altRoster = altRosterReg();
            switch(altRoster){
                case '1':
                    r.insertStudent(rosterNum);
                    std::cout << "Successfully added student" << std::endl;
                    break;
                case '2':
                    r.removeStudent(rosterNum);
                    std::cout << "Successfully dropped student" << std::endl;
                    break;
                case '3':
                    r.updateStudent(rosterNum);
                    std::cout << "Successfully updated student" <<std::endl;
                    break;
                case '4':
                    std::cout << "Exiting Program" <<std::endl;
                    break;
                default:
                    std::cout <<"No option found" << std::endl;
                    break;
            }
        }
    }
    if(response == 'E'){
        std::cout << "Ending Program..." << std::endl;
        return 0;
    }
    return 0;
}

char menu(){
    char ans;
    std::cout << "Press 1 to add a new roster" << std::endl
        << "Press 2 to drop a roster" << std::endl
        << "Press 3 to view a roster" << std::endl
        << "Press 4 to view every roster" << std::endl
        << "Press 5 to exit the program" << std::endl;
    std::cin >> ans;
    return ans;
}
char altRosterSup(){
    char ans;
    std::cout << "Press 1 to add a new student" << std::endl
        << "Press 2 to drop a student" << std::endl
        << "Press 3 to update a student" << std::endl
        << "Press 4 to view every student" << std::endl
        << "Press 5 to return to the main menu" << std::endl;
    std::cin >> ans;
    return ans;
}

char altRosterReg(){
    char ans;
    std::cout << "Press 1 to add a new student" << std::endl
        << "Press 2 to drop a student" << std::endl
        << "Press 3 to update a student" << std::endl
        << "Press 4 to return to the main menu" << std::endl;
    std::cin >> ans;
    return ans;
}